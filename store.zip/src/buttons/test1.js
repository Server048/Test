export const customID = 'role_list'

export default async (interaction) => {
        await interaction.reply({
                content: 'Ini Test 1 Ke 1',
                ephemeral: true
        })
}

