export const customID = 'balance'

export default async (interaction) => {
        await interaction.reply({
                content: 'Ini Test balance Ke 1',
                ephemeral: true
        })
}

