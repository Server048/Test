export const customID = 'buy_role'

export default async (interaction) => {
        await interaction.reply({
                content: 'Ini Test',
                ephemeral: true
        })
}
