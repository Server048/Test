import { Schema, model } from 'mongoose'

export let test1 = new Schema({
        Content: String
})

export default model('TestInys7i', test1)
