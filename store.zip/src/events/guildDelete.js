export default (guild) => {
	console.log(`Left guild ${guild.name} with ${guild.memberCount} members!`)
}
