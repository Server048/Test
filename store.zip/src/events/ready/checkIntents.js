import checkIntents from '../../utils/checkIntents.js'

export default async (client) => checkIntents(client)
